package com.zkos.helloworld.viewmodel;

import lombok.Getter;
import org.zkoss.bind.annotation.Init;
import org.zkoss.bind.annotation.ExecutionArgParam;

@Getter
public class UserDetailVM {
    private String npk;
    private String nama;
    private String posisi;
    private String status;

    @Init
    public void init(@ExecutionArgParam("npk") String npk,
                     @ExecutionArgParam("nama") String nama,
                     @ExecutionArgParam("posisi") String posisi,
                     @ExecutionArgParam("status") String status) {
        this.npk = npk;
        this.nama = nama;
        this.posisi = posisi;
        this.status = status;
    }
}